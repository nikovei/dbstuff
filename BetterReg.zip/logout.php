<?php
// Believe it or not, session_start, starts the session.
session_start();
 
// Unset all of the session variables
$_SESSION = array();
 
// Draxx 2.0 the destroyer of sessions
session_destroy();
 
// Takes you to the login page
header("location: login.php");
exit;
?>