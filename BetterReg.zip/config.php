<?php
define('DB_SERVER', 'trisent.database.windows.net');
define('DB_email', 'overlord');
define('DB_PASSWORD', 'DBadmin1');
define('DB_NAME', 'userdb');
 

$link = mysqli_connect(DB_SERVER, DB_NAME, DB_PASSWORD, DB_NAME);
 
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
